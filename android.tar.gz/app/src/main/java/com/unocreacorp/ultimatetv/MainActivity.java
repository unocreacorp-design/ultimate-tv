package com.unocreacorp.ultimatetv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Ultimate TV: abre la página publicada en GitHub a pantalla completa y la adapta al control remoto. */
public class MainActivity extends Activity {
  static final String URL = "https://unocreacorp-design.github.io/ultimate-tv/";
  static final String OFFLINE = "<html><body style='margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;background:#070b11;color:#eef3f9;font-family:sans-serif;text-align:center'>"
      + "<div style='font-size:48px'>📡</div><h2 style='margin:0'>Sin conexión a internet</h2>"
      + "<p style='color:#8fa1b6;margin:0'>Revisa el Wi-Fi del televisor y vuelve a intentarlo.</p>"
      + "<button autofocus onclick=\"location.href='" + URL + "'\" style='font-size:20px;padding:12px 28px;border-radius:999px;border:0;background:#ff8a3d;color:#1d0d02;font-weight:bold'>Reintentar</button>"
      + "</body></html>";

  private WebView web;
  private long lastBack = 0;

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    web = new WebView(this);
    web.setBackgroundColor(Color.parseColor("#070b11"));
    setContentView(web);
    hideBars();

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); // deja ver canales con enlace http
    s.setUseWideViewPort(true);
    s.setLoadWithOverviewMode(true);
    s.setUserAgentString(s.getUserAgentString() + " UltimateTVApp/1.0");

    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        return !r.getUrl().toString().startsWith(URL); // la app no sale de Ultimate TV
      }
      @Override
      public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
        if (r.isForMainFrame()) v.loadDataWithBaseURL(URL, OFFLINE, "text/html", "utf-8", null);
      }
    });

    if (state != null) web.restoreState(state); else web.loadUrl(URL);
    web.requestFocus();
  }

  private void hideBars() {
    getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  }

  @Override
  public boolean dispatchKeyEvent(KeyEvent e) {
    int k = e.getKeyCode();
    if (k == KeyEvent.KEYCODE_BACK) {
      if (e.getAction() == KeyEvent.ACTION_UP) handleBack();
      return true;
    }
    if ((k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_CHANNEL_DOWN) && e.getAction() == KeyEvent.ACTION_DOWN) {
      web.evaluateJavascript("window.utvChannel&&window.utvChannel(" + (k == KeyEvent.KEYCODE_CHANNEL_UP ? -1 : 1) + ")", null);
      return true;
    }
    return super.dispatchKeyEvent(e);
  }

  private void handleBack() {
    web.evaluateJavascript("(window.utvBack?window.utvBack():false)", v -> {
      if ("true".equals(v)) return;
      long now = System.currentTimeMillis();
      if (now - lastBack < 2000) finish();
      else { lastBack = now; Toast.makeText(this, "Oprime Atrás otra vez para salir", Toast.LENGTH_SHORT).show(); }
    });
  }

  @Override protected void onResume() { super.onResume(); hideBars(); web.onResume(); }
  @Override protected void onPause() { web.onPause(); super.onPause(); }
  @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
  @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
